package com.ait.util;

public class RestConstant {
public static final String GET_ALL_TICKET="/tickets";

public static final String GET_TICKET_BY_ID="/ticket/{id}";

public static final String CREATE_TICKET="/ticket";

public static final String UPDATE_TICKET="/ticket";

public static final String DELETE_TICKET="/ticket/{id}";

}
